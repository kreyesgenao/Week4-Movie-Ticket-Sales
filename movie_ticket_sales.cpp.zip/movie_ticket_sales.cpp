#include <iostream>
#include <iomanip>
#include <limits>
#include <string>
#include <sstream>
using namespace std;

int main() {
    string anotherSession = "Y";

    cout << "Welcome to the Movie Theater Ticket Sales System!\n";
    cout << fixed << setprecision(2);

    // Repeat sales sessions until the user chooses N.
    while (anotherSession == "Y" || anotherSession == "y") {

        // Reset all totals for the new session.
        int numberOfCustomers = 0;
        int childTickets = 0;
        int adultTickets = 0;
        int seniorTickets = 0;
        int totalTickets = 0;

        double totalRevenue = 0.0;
        double averageTransaction = 0.0;

        string input;
        char extra;

        // Ask for and validate the number of customers.
        cout << "\nEnter the number of customers (1-50): ";

        while (true) {
            if (!getline(cin, input)) {
                return 0;
            }

            istringstream entry(input);

            if ((entry >> numberOfCustomers) &&
                !(entry >> extra) &&
                numberOfCustomers >= 1 &&
                numberOfCustomers <= 50) {
                break;
            }

            cout << "Invalid input. Enter a whole number from 1 to 50: ";
        }

        // Process each customer's purchase.
        for (int customer = 1;
             customer <= numberOfCustomers;
             customer++) {

            int ticketQuantity = 0;
            int choice = 0;
            double ticketPrice = 0.0;
            double transactionTotal = 0.0;
            string ticketCategory;

            cout << "\nCustomer " << customer << "\n";
            cout << "------------------------------\n";

            // Validate the ticket quantity.
            cout << "How many tickets would you like (1-10)? ";

            while (true) {
                if (!getline(cin, input)) {
                    return 0;
                }

                istringstream entry(input);

                if ((entry >> ticketQuantity) &&
                    !(entry >> extra) &&
                    ticketQuantity >= 1 &&
                    ticketQuantity <= 10) {
                    break;
                }

                cout << "Invalid quantity. Enter a whole number from 1 to 10: ";
            }

            // Display the ticket category menu.
            cout << "\nSelect Ticket Category\n";
            cout << "1. Child (12 and under) - $8.00\n";
            cout << "2. Adult (13-59)        - $12.00\n";
            cout << "3. Senior (60 and over) - $9.00\n";
            cout << "Enter your selection (1-3): ";

            // Validate the category selection.
            while (true) {
                if (!getline(cin, input)) {
                    return 0;
                }

                istringstream entry(input);

                if ((entry >> choice) &&
                    !(entry >> extra) &&
                    choice >= 1 &&
                    choice <= 3) {
                    break;
                }

                cout << "Invalid selection. Please enter 1, 2, or 3: ";
            }

            // Assign the price and count tickets by category.
            if (choice == 1) {
                ticketCategory = "Child";
                ticketPrice = 8.00;
                childTickets += ticketQuantity;
            }
            else if (choice == 2) {
                ticketCategory = "Adult";
                ticketPrice = 12.00;
                adultTickets += ticketQuantity;
            }
            else {
                ticketCategory = "Senior";
                ticketPrice = 9.00;
                seniorTickets += ticketQuantity;
            }

            // Calculate the purchase and update session totals.
            transactionTotal = ticketQuantity * ticketPrice;

            totalTickets += ticketQuantity;
            totalRevenue += transactionTotal;

            // Display this customer's purchase.
            cout << "\nTicket Category:   " << ticketCategory << "\n";
            cout << "Tickets Purchased: " << ticketQuantity << "\n";
            cout << "Price Per Ticket:  $" << ticketPrice << "\n";
            cout << "Transaction Total: $" << transactionTotal << "\n";
            cout << "Thank you for your purchase!\n";
        }

        // Calculate the average after processing all customers.
        averageTransaction = totalRevenue / numberOfCustomers;

        // Display the sales summary.
        cout << "\n========================================\n";
        cout << "       MOVIE THEATER SALES REPORT\n";
        cout << "========================================\n";
        cout << "Customers Processed: " << numberOfCustomers << "\n";
        cout << "\nChild Tickets Sold:  " << childTickets << "\n";
        cout << "Adult Tickets Sold:  " << adultTickets << "\n";
        cout << "Senior Tickets Sold: " << seniorTickets << "\n";
        cout << "\nTotal Tickets Sold:  " << totalTickets << "\n";
        cout << "Total Revenue:       $" << totalRevenue << "\n";
        cout << "Average Transaction: $" << averageTransaction << "\n";
        cout << "========================================\n";

        // Ask whether to process another session.
        cout << "\nWould you like to process another sales session?\n";
        cout << "Enter Y for Yes or N for No: ";

        if (!getline(cin, anotherSession)) {
            return 0;
        }

        while (anotherSession != "Y" && anotherSession != "y" &&
               anotherSession != "N" && anotherSession != "n") {
            cout << "Invalid response. Please enter Y or N: ";

            if (!getline(cin, anotherSession)) {
                return 0;
            }
        }
    }

    cout << "\nThank you for using the program. Goodbye!\n";

    return 0;
}